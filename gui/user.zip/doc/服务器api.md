## API 列表说明

### 一、学校端（School Server）

学校端运行于各学校本地，负责管理本校的衣物激活、用户消息、丢失上报及衣物删除等。

**统一响应结构**
```json
{
  "Phrase": "描述信息",
  "Status": true/false,
  "Detail": {}
}
```

---

#### 1. 激活衣物
**`POST /service/enable`**

将衣物与用户绑定并激活。

**请求体 (JSON)**
| 字段      | 类型   | 必填 | 说明                     |
|-----------|--------|------|--------------------------|
| `yid`     | string | 是   | 衣物唯一标识             |
| `uid`     | string | 是   | 用户唯一标识             |
| `student` | string | 是   | 学号（如 `"20240101"`）  |

**响应示例**
```json
{
  "Phrase": "enable success",
  "Status": true,
  "Detail": {}
}
```

---

#### 2. 获取用户消息
**`POST /user/get_msg`**

查询指定用户的所有未删除消息。

**请求体 (JSON)**
| 字段  | 类型   | 必填 | 说明         |
|-------|--------|------|--------------|
| `uid` | string | 是   | 用户唯一标识 |

**响应示例**
```json
{
  "Phrase": "get msg success",
  "Status": true,
  "Detail": {
    "msg": {
      "1716700000": {
        "type": 1,
        "time": 1716700000,
        "auto_delete": false,
        "detail": {
          "yid": "some_yid",
          "name": "学校名称"
        }
      }
    }
  }
}
```
> 说明：`msg` 对象键为消息时间戳（整数秒），值为消息详情。消息类型：1-丢失通知，2-通知用户已领取，3-激活衣服通知，4-学校删除衣服通知。

---

#### 3. 上报衣物丢失
**`POST /service/loss`**

标记衣物丢失并向用户发送类型为1的消息。

**请求体 (JSON)**
| 字段  | 类型   | 必填 | 说明         |
|-------|--------|------|--------------|
| `yid` | string | 是   | 衣物唯一标识 |

**成功响应**
```json
{
  "Phrase": "lossing report successful",
  "Status": true,
  "Detail": {}
}
```

**错误响应示例（衣物不存在）**
```json
{
  "Phrase": "yid not found",
  "Status": false,
  "Detail": {}
}
```
HTTP 状态码：404

---

#### 4. 管理员删除衣物
**`POST /admin/delete`**

管理员验证本地和远程密码后删除衣物，并发送类型为4的通知。

**请求体 (JSON)**
| 字段              | 类型   | 必填 | 说明               |
|-------------------|--------|------|--------------------|
| `password_local`  | string | 是   | 本地管理员密码     |
| `password_remote` | string | 是   | 远程服务管理员密码 |
| `yid`             | string | 是   | 衣物唯一标识       |

**成功响应**
```json
{
  "Phrase": "delete uniform",
  "Status": true,
  "Detail": {}
}
```

**错误响应示例（密码错误）**
```json
{
  "Phrase": "forbidden",
  "Status": false,
  "Detail": {}
}
```
HTTP 状态码：403

---

### 二、总服务器端（Central Server）

总服务器端作为中心节点，管理学校注册、衣物生成、用户激活、丢失上报转发及学校端衣物删除等。

**统一响应结构**
```json
{
  "Phrase": "描述信息",
  "Status": true/false,
  "Detail": {}
}
```

---

#### 1. 生成衣物ID
**`POST /maker/make`**

为指定学校生成新的未激活衣物ID（YID）。

**请求体 (JSON)**
| 字段  | 类型   | 必填 | 说明                         |
|-------|--------|------|------------------------------|
| `sid` | string | 是   | 学校唯一标识                 |
| `yid` | string | 否   | （调试模式可用）指定衣物ID   |

**成功响应示例**
```json
{
  "Phrase": "Make uniform success",
  "Status": true,
  "Detail": {
    "YID": "550e8400-e29b-41d4-a716-446655440000"
  }
}
```

**错误响应示例**
- 缺少 `sid`：HTTP 400
- `sid` 不存在：HTTP 404

---

#### 2. 学校注册
**`POST /school/register`**

新学校在总服务器注册。

**请求体 (JSON)**
| 字段              | 类型   | 必填 | 说明                         |
|-------------------|--------|------|------------------------------|
| `name`            | string | 是   | 学校名称                     |
| `sid`             | string | 是   | 学校唯一标识（不可重复）     |
| `password`        | string | 是   | 管理员密码                   |
| `school_service`  | string | 是   | 学校服务的基础URL            |

**成功响应**
```json
{
  "Phrase": "register successfully",
  "Status": true,
  "Detail": {}
}
```

**错误响应示例**
- 缺少必填字段：HTTP 400
- 学校名称或 `sid` 已存在：HTTP 400

---

#### 3. 用户激活衣物
**`POST /user/enable`**

用户绑定并激活某衣物，同时通知对应学校进行本地激活。

**请求体 (JSON)**
| 字段      | 类型   | 必填 | 说明                     |
|-----------|--------|------|--------------------------|
| `yid`     | string | 是   | 衣物唯一标识             |
| `uid`     | string | 是   | 用户唯一标识             |
| `student` | string | 是   | 学号（如 `"20240101"`）  |

**成功响应**
```json
{
  "Phrase": "enable successfully",
  "Status": true,
  "Detail": {
    "school_service": "http://school.example.com",
    "name": "学校名称"
  }
}
```

**错误响应示例**
- 缺少必填字段：HTTP 400
- `yid` 不存在：HTTP 404
- 衣物已激活：HTTP 423
- 通知学校失败：状态码随学校返回，Detail 包含学校错误信息

---

#### 4. 上报衣物丢失
**`POST /user/loss`**

用户上报衣物丢失，总服务器转发通知到学校。

**请求体 (JSON)**
| 字段  | 类型   | 必填 | 说明         |
|-------|--------|------|--------------|
| `yid` | string | 是   | 衣物唯一标识 |

**成功响应**
```json
{
  "Phrase": "lossing report successfully",
  "Status": true,
  "Detail": {
    "sid": "学校ID"
  }
}
```

**错误响应示例**
- `yid` 不存在：HTTP 404
- 衣物未激活：HTTP 423
- 通知学校失败：状态码随学校返回

---

#### 5. 学校删除衣物
**`POST /school/delete`**

学校管理员验证密码后，从总服务器删除衣物记录。

**请求体 (JSON)**
| 字段       | 类型   | 必填 | 说明               |
|------------|--------|------|--------------------|
| `yid`      | string | 是   | 衣物唯一标识       |
| `sid`      | string | 是   | 学校唯一标识       |
| `password` | string | 是   | 学校管理员密码     |

**成功响应**
```json
{
  "Phrase": "delete successfully",
  "Status": true,
  "Detail": {}
}
```

**错误响应示例**
- 密码错误：HTTP 403
- `yid` 不存在或不属于该学校：HTTP 404
- 衣物未激活：HTTP 423